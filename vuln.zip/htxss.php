<?php


//Text Reflect in HTML

$text = $_GET['text'];

$text_with_encoder = htmlentities($text);

echo   $text_with_encoder  ;

//-----------------------------------------------------------------------------------

// Text Reflect in Script tag

header("Content-Security-Policy: default-src 'self'");

$text = $_GET['text'];

$text_with_encoder = htmlentities($text);

echo  '<script>' . $text_with_encoder . '</script>' ;


?>

