<?php

 $servername = "localhost";
$username = "id19228282_tedt132";
$password = "K&}8&AUE8F/pYHfD";
$db = "id19228282_tedt";
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$id = $_GET['id'];

if(! (is_numeric($id))){
    echo 'something wrong';
    exit();
}
      $sql = "SELECT * FROM heroes where id =".$id;
    //   $result = $conn->query($sql);
  $result = mysqli_query($conn, $sql );
  
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
   echo '<tr>'.
                            '<td>' .$row["name"]  . '</td> </br>'.
                             '<td>' . $row["realname"] . '</td> </br>'.
                           '<td>' . $row["rating"] . '</td></br>'.
                           '<td>' .$row["teamaffiliation"]  . '</td>';
  }
} else {
  echo "0 results";
}


?>
