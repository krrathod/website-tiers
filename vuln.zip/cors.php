<?php



// header("Content-Security-Policy: default-src 'self'");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");

?>