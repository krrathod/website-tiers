<?php
$date = date('Y-m-d H:i:s');
$time_input = strtotime("+15 minutes",strtotime("2022-11-09 11:21:40")); 
echo '</br>'. date('Y-m-d H:i:s', $time_input) . '</br>';
echo $date . '</br>' ;

if($time_input>date('Y-m-d H:i:s', $time_input)){
    echo 'Your Account is lock';
}else{
    echo 'Your Account is not lock';
}

?>