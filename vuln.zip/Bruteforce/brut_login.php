<?php 

session_start(); 

include 'db.php';



if (isset($_POST['uname']) && isset($_POST['password'])) {

 

    $uname = $_POST['uname'];
    $pass = $_POST['password'];
    
    $check_lock = "SELECT * FROM users WHERE username = '$uname'";
    $check_lock_result = $conn->query($check_lock);
    
    if ($check_lock_result->num_rows > 0) {

        while($loc_row = $check_lock_result->fetch_assoc()) {
             if($loc_row['throat']>0){
               
                $login = "SELECT * FROM users WHERE username = '$uname' AND password= '$pass'";
                $login_result = $conn->query($login);
                if ($login_result->num_rows > 0) 
                { while($row = $login_result->fetch_assoc()) {
                $update_throe1 = "UPDATE `users` SET `throat`= 3 WHERE username = '$uname'";
                $update_throe_re1 = $conn->query($update_throe1);
                    echo 'login successfully'; }}
             
             
                else{
                    $tr = ($loc_row['throat']) - 1;
                    echo 'Remaining throat is '. $tr;
                    $date = date('Y-m-d H:i:s');
                    $update_throe2 = "UPDATE `users` SET `throat`= $tr, `time_stemp`= '$date' WHERE username = '$uname'";
                    $update_throe_re2 = $conn->query($update_throe2);
                } 
                 
             }else{
                
            $time_input = strtotime("+1 minutes",strtotime($loc_row['time_stemp'])); 
            echo date('Y-m-d H:i:s') . '</br>';
            if(date('Y-m-d H:i:s', $time_input) > date('Y-m-d H:i:s')){
                echo 'Account is locked';
            }else{
                echo 'Acount is unlock';
                 $update_throe2 = "UPDATE `users` SET `throat`= 3, `time_stemp`= ' ' WHERE username = '$uname'";
                    $update_throe_re2 = $conn->query($update_throe2);
            }
        }}
                
      }
            

}    




?>