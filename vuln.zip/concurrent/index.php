<?php
include 'db.php';
session_start();
if(isset($_SESSION["user_token"])){
    
    $user = $_SESSION["user_token"];
    $sql = "SELECT * FROM users WHERE user_token = '$user'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {    
          while($row = $result->fetch_assoc()) {
        echo 'Account : '. $row["username"] .'</br></br>';
        echo '<a href="logout.php"> logout</a>'; }
        
    }
    else{
    echo 'You are not login </br></br>';
    echo '<a href="concurrent.php">login</a>';
}
    

}else{
    echo 'You are not login </br></br>';
    echo '<a href="concurrent.php">login</a>';
}


?>