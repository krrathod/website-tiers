<?php 

session_start(); 

include 'db.php';

if(isset($_SESSION['user_token']) && !empty($_SESSION['user_token'])) {
  header('Location: concurrent_index.php');
  exit();
}

$t=time();
if (isset($_POST['uname']) && isset($_POST['password'])) {

 

    $uname = $_POST['uname'];

    $pass = $_POST['password'];
    
    $sql = "SELECT * FROM users WHERE username = '$uname' AND password = '$pass'";
    
    $result = $conn->query($sql);
    
    
    
     if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()) {
                    
                    // Here Our Main Code
                    
                    //Here we check our User is Active or not
             
                          $user = $row['username'];
                       $_SESSION["user_token"] = generateRandomString();
                       $user_token = $_SESSION["user_token"];
                       $update_time = "UPDATE `users` SET `user_token`= '$user_token' WHERE username='$user'";
                       if($conn->query($update_time)){
                           //echo 'done';
                       header('Location: index.php');
                           
                       }
                    
                       
                       
      } 



}else{
 echo 'not logen'; 
}
} 

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>