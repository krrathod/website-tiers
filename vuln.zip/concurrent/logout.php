<?php
include 'db.php';
session_start();
$user = $_SESSION["user_token"];
$leave = "UPDATE `users` SET `Status`='Offline',`user_token`= '' WHERE user_token='$user'";
$leave_res = $conn->query($leave);
if($leave_res){
    session_destroy();
header("Location: index.php");
}



?>